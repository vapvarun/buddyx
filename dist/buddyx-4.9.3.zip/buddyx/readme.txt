=== BuddyX ===
Contributors: wbcomdesigns, vapvarun
Tags: buddypress, community, translation-ready, accessibility-ready, mobile-first, ecommerce, woocommerce
Requires at least: 5.4
Tested up to: 6.4
Requires PHP: 8.0
Stable tag: 3.1.0
License: GNU General Public License v3.0 (or later)
License URI: https://www.gnu.org/licenses/gpl-3.0.html

A powerful WordPress theme designed specifically for building online communities and social networks.

== Description ==

BuddyX is a flexible, modern WordPress theme built with community and BuddyPress integration in mind. Creating a theme with BuddyX means adopting this approach and core principles it is built on:

* Accessibility First - WCAG compliant and screen reader friendly
* Mobile-First Design - Responsive across all devices  
* Progressive Enhancement - Works for everyone, regardless of browser capabilities
* Performance Optimized - Fast loading and efficient
* BuddyPress Ready - Perfect for community features
* WooCommerce Compatible - E-commerce ready
* Developer Friendly - Clean code, well-documented

== Features ==

* Community-focused design with BuddyPress integration
* Multiple header layouts and navigation options
* Customizable color schemes and typography
* Widget-ready sidebars and footer areas
* Built-in block patterns and templates
* WooCommerce compatibility for e-commerce
* Optimized asset loading and performance
* AMP support for mobile performance
* Modern build system with ESBuild
* Component-based architecture
* Custom block development support
* Comprehensive testing suite

== Installation ==

1. Upload the theme folder to your /wp-content/themes/ directory
2. Activate the theme through the WordPress admin panel under Appearance > Themes
3. Configure theme settings through Appearance > Customize

== Frequently Asked Questions ==

= Does BuddyX work with WordPress 6.0+? =

Yes, BuddyX is tested and compatible with the latest WordPress versions.

= What plugins work best with BuddyX? =

* BuddyPress - for community features
* WooCommerce - for e-commerce functionality  
* bbPress - for forum functionality
* LearnDash - for learning management systems

= How do I customize BuddyX? =

Through the WordPress Customizer, theme options panel, or by creating a child theme. Developer documentation is available in the theme repository.

= Is BuddyX accessible? =

Yes, BuddyX follows WCAG 2.1 guidelines and includes screen reader support, keyboard navigation, and semantic markup.

= Can I use BuddyX for commercial projects? =

Yes, BuddyX is licensed under GPL v3.0 and can be used for both personal and commercial projects.

== Development ==

For developers who want to contribute or extend BuddyX:

* Node.js 20.13.1+ and npm 10.5.2+ required for development
* Modern build system with ESBuild
* Component-based architecture
* Custom block development support
* WP CLI commands included

== Changelog ==

= 3.1.0 =
* Complete rebranding from BuddyX to BuddyX
* Enhanced BuddyPress integration
* Updated build system and development tools
* New block patterns and templates
* Performance optimizations
* Accessibility improvements
* WooCommerce compatibility updates
* Mobile-first responsive design improvements

= Previous versions =
* See CHANGELOG.md for detailed version history

== Upgrade Notice ==

When upgrading from previous versions, please clear your browser cache and regenerate thumbnails if you experience any display issues.

== Credits ==

* Lead Developers: wbcomdesigns, vapvarun
* Originally based on BuddyX architecture
* Complete reimagining for community and BuddyPress integration
* All contributors: https://github.com/wbcomdesigns/buddyx/graphs/contributors

== License ==

This theme is licensed under the GNU General Public License v3.0 (or later). A copy of the license is included in the theme's license.txt file.